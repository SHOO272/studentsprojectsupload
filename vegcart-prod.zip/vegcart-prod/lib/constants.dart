import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF68a523);
const kSecondaryColor = Color(0xFFFE9901);
const kContentColorLightTheme = Color(0xFF000b1c);
const kContentColorDarkTheme = Colors.white;
