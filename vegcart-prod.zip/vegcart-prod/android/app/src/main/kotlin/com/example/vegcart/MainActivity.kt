package com.example.vegcart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
